import java.util.Queue;
import java.util.Random;
import java.util.LinkedList;

public class CarQueue {
	Queue<Integer> queue;
	Random rand = new Random();
	
	public CarQueue() {
		queue = new LinkedList<>();
		queue.add(3);
		queue.add(3);
		queue.add(3);
		queue.add(3);
		queue.add(0);
	}
	
	public void addToQueue() {
		class temp implements Runnable {
			@Override
			public void run() {
				try {
					for(int i = 0; i < 1000; i++) {
						int num = rand.nextInt(4);
						queue.add(num);
						Thread.sleep(50);
					}
				}catch(Exception exception) {
					exception.printStackTrace();
			}
		}
	}
		Runnable run = new temp();
		Thread t = new Thread(run);
		t.start();
	}
	public int deleteQueue() {
		return queue.remove();
	}
}